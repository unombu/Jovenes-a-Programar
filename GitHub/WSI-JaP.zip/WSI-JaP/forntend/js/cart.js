document.addEventListener("DOMContentLoaded", () => {
    let productos = JSON.parse(localStorage.getItem("carrito")) || [];
    console.log(productos);
    obtenerProductos(productos); //obtiene productos y los muestra
});

document.getElementById("cartProducts").addEventListener("click", (event) => {
    let productos = JSON.parse(localStorage.getItem("carrito")) || [];
    if (event.target.matches(".mas") || event.target.matches(".menos")) {
        const productId = event.target.closest(".box").id.replace("prod-", "");
        const producto = productos?.find(p => p.id == productId);
        if (producto) {
            if (event.target.matches(".mas")) {
                producto.cantidad += 1;
            } else if (event.target.matches(".menos")) {
                producto.cantidad = Math.max(1, producto.cantidad - 1);
            }
            localStorage.setItem("carrito", JSON.stringify(productos));
            actualizarCantidad(productId, producto.cantidad);
            actualizarFactura();
        }
    }
    if (event.target.closest(".borrar")) {
        let productos = JSON.parse(localStorage.getItem("carrito")) || [];
        const productId = event.target.closest(".borrar").getAttribute("name");
        document.getElementById(productId).remove();
        const trashids = productos.filter(p => p.id != productId);
        localStorage.setItem("carrito", JSON.stringify(trashids));
        actualizarFactura();
        if (trashids.length === 0) {
            mostrarCarritoVacio()
        }
    }
});

function iniciarCompra() {
    //create
    createShippingModal();
    createPaymentModal();

    //get elements
    const shippingModal = new bootstrap.Modal(document.getElementById('shippingModal'));
    const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
    const shippingForm = document.getElementById('shippingForm');
    const showMoreFields = document.getElementById('showMoreFields');
    const additionalFields = document.querySelector('.additional-fields');
    const saveAddressBtn = document.getElementById('saveAddressBtn');
    
    //funcionalidad
    shippingModal.show();

    showMoreFields.addEventListener('click', function() {
        additionalFields.classList.add('show');
    });

    shippingForm.addEventListener('submit', function(e) {
        e.preventDefault();
        shippingModal.hide();
        paymentModal.show();
        actualizarCosto();
    });

    saveAddressBtn.addEventListener('click', function() {
        if(saveAdress()){
            additionalFields.classList.remove('show');
        }
    });

    addNewCard();
    const creditCardRadio = document.getElementById('creditCard');
    const bankTransferRadio = document.getElementById('bankTransfer');
    const creditCardContent = document.getElementById('creditCardContent');
    const bankTransferContent = document.getElementById('bankTransferContent');
    const addNewCardBtn = document.getElementById('addNewCardBtn');
    const addCardModal = new bootstrap.Modal(document.getElementById('addCardModal'));
    const addCardForm = document.getElementById('addCardForm');
    const backToShipping = document.getElementById('backToShipping');

    backToShipping.addEventListener('click', function() {
        paymentModal.hide();
        shippingModal.show();
    });

    function togglePaymentMethod() {
        if (creditCardRadio.checked) {
            creditCardContent.style.display = 'block';
            bankTransferContent.style.display = 'none';
        } else {
            creditCardContent.style.display = 'none';
            bankTransferContent.style.display = 'block';
        }
    }

    creditCardRadio.addEventListener('change', togglePaymentMethod);
    bankTransferRadio.addEventListener('change', togglePaymentMethod);

    addNewCardBtn.addEventListener('click', function() {
        paymentModal.hide();
        addCardModal.show();
    });

    addCardForm.addEventListener('submit', function(e) {
        e.preventDefault();
        if(saveCard()){
            addCardModal.hide();
            createPaymentModal();
            paymentModal.show();
        }
    });
    document.getElementById('finalizarCompra').addEventListener('click', finalizarCompra);
}













//------------------------------------------------AUXILIARES----------------------------------------------------------//
function obtenerProductos(arrayProductos) {
    if (arrayProductos.length > 0) {
        let urls = arrayProductos.map(prod => "http://localhost:3000/productos/" + prod.id );
        const promises = urls.map(url => getJSONData(url));
        Promise.all(promises)
            .then(results => {
                console.log("Datos obtenidos:", results);
                results.forEach(productoData => {
                    const producto = arrayProductos.find(p => p.id === productoData.data.id);
                    createProducto(productoData.data, producto.cantidad);
                });
            })
            .catch(error => console.error("Error en el fetch de productos:", error));
    } else {
        mostrarCarritoVacio();
    }
}

function createProducto(producto, cantidad) {
    const precioUSD = producto.currency === "USD" ? producto.cost : producto.cost / 40;
    const HTMLContent = `
        <div class="row w-100 m-3 mb-1 p-3 border rounded-3 box" id="${producto.id}">
            <div class="col-4">
                <img src="${producto.images[0]}" class="img-fluid rounded mx-auto d-block" style="max-height: 10rem;"/>
            </div>
            <div class="col-8">
                <div class="d-flex justify-content-between">
                    <h4>${producto.name}</h4>
                    <button class="borrar" name="${producto.id}" style="border: 0;">
                        <img src="img/bin.png" style="width: 2rem;"/>
                    </button>
                </div>
                <p style="color: darkgreen;">Envío gratis</p>
                <br>
                <div class="btn-group w-25" role="group">
                    <button type="button" class="btn btn-dark menos">-</button>
                    <button type="button" class="btn btn-dark cantidad" id="prod-${producto.id}" disabled>${cantidad}</button>
                    <button type="button" class="btn btn-dark mas">+</button>
                </div>
                <p class="precio">USD ${precioUSD.toFixed(2)}</p>
            </div>
        </div>
    `;
    document.getElementById("cartProducts").innerHTML += HTMLContent;
    actualizarFactura();
}

function actualizarFactura() {
    const productos = JSON.parse(localStorage.getItem("carrito")) || [];
    let totalPrecio = calcularPrecio();
    document.getElementById("factura").innerHTML = `
        <div class="container m-3 p-3 border rounded-3 box">
            <h5>Resumen de compra</h5><br>
            <div class="">
                <div class="">
                <div class="linefactura"><p>PRODUCTOS (${productos.length})</p><p>USD ${totalPrecio.toFixed(2)}</div>
                    <div class="linefactura"> <p>ENVÍO</p> <p style="color: darkgreen;">GRATIS</p></div><br>
                    <div class="linefactura"><h6>SUBTOTAL:</h6><h6>USD ${totalPrecio.toFixed(2)}</h6></div><br>
                    <div class="linefactura"><h1>TOTAL:</h1><h1>USD ${totalPrecio.toFixed(2)}</h1></div>
                </div>
            </div>
            <button id="iniciarCompra" onclick="iniciarCompra()" class="btn btn-primary rounded-4 w-100 mt-3" ${productos.length === 0 ? 'disabled' : ''}>
                INICIAR COMPRA
            </button>
        </div>
    `;
}

function actualizarCantidad(id, cantidad) {
    const cantidadElem = document.getElementById(`prod-${id}`);
    if (cantidadElem) cantidadElem.innerHTML = cantidad;
}

function calcularPrecio(){
    const productos = JSON.parse(localStorage.getItem("carrito")) || [];
    let totalPrecio = 0;
    productos.forEach(prod => {
        const item = document.getElementById(prod.id);
        if (item) {
            const precio = parseFloat(item.querySelector(".precio").textContent.split(" ")[1]);
            totalPrecio += precio * prod.cantidad;
        }
    });
    return totalPrecio;
}

function mostrarCarritoVacio() {
    document.getElementById("cartProducts").innerHTML = `
        <div class="container text-center my-4">
            <h3>No hay productos en el carrito</h3>
            <a href="categories.html" class="btn btn-primary rounded-4 w-50 mt-3">Buscar productos</a>
        </div>
    `;
    actualizarFactura();
}

function saveCard() {
    // Obtener los datos del formulario
    const cardNumber = document.getElementById("cardNumber").value.trim();
    const fullName = document.getElementById("fullName").value.trim();
    const expiryDate = document.getElementById("expiryDate").value.trim();
    const cvv = document.getElementById("cvv").value.trim();
    const cardType = document.querySelector('input[name="cardType"]:checked')?.value || null;

    // Verificacion de datos
    const cardNumberPattern = /^[0-9\s]+$/;
    const namePattern = /^[a-zA-Z\s]+$/;
    const expiryDatePattern = /^(0[1-9]|1[0-2])\/\d{2}$/;
    const cvvPattern = /^[0-9]{3,4}$/;

    let errorMessage = "";

    if (!cardNumberPattern.test(cardNumber)) {
        errorMessage = "El número de tarjeta solo puede contener números.";
    }
    if (!namePattern.test(fullName)) {
        errorMessage = "El nombre completo solo puede contener letras y espacios.";
    }
    if (!expiryDatePattern.test(expiryDate)) {
        errorMessage = "La fecha de expiración debe tener el formato MM/AA.";
    }
    if (!cvvPattern.test(cvv)) {
        errorMessage = "El CVV debe tener entre 3 y 4 dígitos.";
    }
    console.log(cardType)
    if (cardType == null) {
        errorMessage = "Por favor, selecciona el tipo de tarjeta.";
    }

    if (errorMessage != "") {
        document.getElementById("error-newCard").textContent = errorMessage;
        return false;
    }

    let cards = JSON.parse(localStorage.getItem("cards")) || [];

    let id = cards.length;
    // Creo la tarjeta
    const card = {
        id,
        cardNumber,
        fullName,
        expiryDate,
        cvv,
        cardType
    };

    //la guardo
    cards.push(card);
    localStorage.setItem("cards", JSON.stringify(cards));

    document.getElementById("error-newCard").textContent = "";
    document.getElementById("addCardForm").reset();
    return true;
}


function saveAdress() {
    const addressName = document.getElementById('addressName');
    const department = document.getElementById('department');
    const locality = document.getElementById('locality');
    const street = document.getElementById('street');
    const number = document.getElementById('number');
    const corner = document.getElementById('corner');

    const nuevaDireccion = {
        nombre: addressName.value.trim(),
        departamento: department.value.trim(),
        localidad: locality.value.trim(),
        calle: street.value.trim(),
        numero: number.value.trim(),
        esquina: corner.value.trim()
    };

    for (const [campo, valor] of Object.entries(nuevaDireccion)) {
        if (!valor) {
            document.getElementById("error-nuevaDir").textContent = `Por favor, completa el campo: ${campo}`;
            return false;
        }
    }

    let direcciones = JSON.parse(localStorage.getItem('direcciones')) || [];
    direcciones.push(nuevaDireccion);
    localStorage.setItem('direcciones', JSON.stringify(direcciones));

    addressName.value = '';
    department.value = '';
    locality.value = '';
    street.value = '';
    number.value = '';
    corner.value = '';
    document.getElementById("error-nuevaDir").textContent = ``;

    createShippingModal();
    return true;
}


function actualizarCosto(){

    const costoBase = calcularPrecio()
     
    const envioSeleccionado = document.getElementById("shippingType").value;

    let porcentajeEnvio;
    switch(envioSeleccionado){
        case "premium":
            porcentajeEnvio = 0.15;
            break;
        case "express":
            porcentajeEnvio = 0.07;
            break;
        case "standard":
            porcentajeEnvio = 0.05;
            break;
        default:
            porcentajeEnvio = 0;
    }
    const costoEnvio = costoBase * porcentajeEnvio;
    const costoTotal = costoBase + costoEnvio;

    document.getElementById("costoEnvio").textContent = "$" + costoEnvio.toFixed(2);
    document.getElementById("costoTotal").textContent = "$" + costoTotal.toFixed(2);
}

function createShippingModal() {
    let direcciones = JSON.parse(localStorage.getItem('direcciones')) || [];

    const modalsHtml = `
    <!-- Shipping Modal -->
    <div class="modal fade" id="shippingModal" tabindex="-1" aria-labelledby="shippingModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
              <div class="modal-header border-0 pb-0">
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body pt-0">
                  <h5 class="modal-title text-center mb-4" id="shippingModalLabel">Detalles de Envío</h5>
                  
                  <div class="d-flex justify-content-center gap-4 mb-4">
                      <div class="d-flex flex-column align-items-center">
                          <div class="icon-container">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <rect x="1" y="3" width="15" height="13"></rect>
                                  <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                                  <circle cx="5.5" cy="18.5" r="2.5"></circle>
                                  <circle cx="18.5" cy="18.5" r="2.5"></circle>
                              </svg>
                          </div>
                      </div>
                      <div class="d-flex flex-column align-items-center">
                          <div class="icon-container">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <rect x="2" y="5" width="20" height="14" rx="2" ry="2"></rect>
                                  <line x1="2" y1="10" x2="22" y2="10"></line>
                              </svg>
                          </div>
                      </div>
                  </div>

                  <form id="shippingForm">
                      <div class="mb-3">
                          <label for="shippingType" class="form-label">Tipo de envío</label>
                          <select id="shippingType" class="form-select" required>
                              <option value="standard">Standard (12 a 15 días) (5%)</option>
                              <option value="express">Express (5 a 8 días) (7%)</option>
                              <option value="premium">Premium (2 a 5 días) (15%)</option>
                          </select>
                      </div>

                      <div class="mb-3">
                          <label for="shippingAddress" class="form-label">Dirección de envío</label>
                          <select id="shippingAddress" class="form-select mb-2" required>
                              <option disabled selected value="">Seleccionar una dirección</option>
                            <!-- ........ACA EN REALIDAD IRIAN LAS DIRECCIONES CUANDO SE AGREGUEN .......-->

                          </select>
                          <div class="d-flex justify-content-center align-items-center">
                            <button type="button" class="btn btn-outline-primary" id="showMoreFields">
                                <i class="bi bi-plus-circle" style="font-size: 16px; padding-right: 5px;"></i>
                                Agregar nueva dirección
                            </button>
                          </div>
                      </div>

                      <div style="text-align: center;">
                          <span id="error-nuevaDir" style="color: red;"></span>
                      </div>

                      <div class="additional-fields">
                          <div class="mb-3">
                              <input type="text" class="form-control" id="addressName" placeholder="Nombre de la dirección">
                          </div>

                          <div class="mb-3">
                              <input type="text" class="form-control" id="department" placeholder="Departamento">
                          </div>

                          <div class="mb-3">
                              <input type="text" class="form-control" id="locality" placeholder="Localidad">
                          </div>

                          <div class="mb-3">
                              <input type="text" class="form-control" id="street" placeholder="Calle">
                          </div>

                          <div class="mb-3">
                              <input type="text" class="form-control" id="number" placeholder="Número">
                          </div>

                          <div class="mb-3">
                              <input type="text" class="form-control" id="corner" placeholder="Esquina">
                          </div>

                          <button type="button" class="btn btn-primary w-100 mb-2" id="saveAddressBtn">
                              Guardar nueva dirección
                          </button>
                      </div>

                      <button type="submit" class="btn btn-primary w-100">
                          Continuar
                      </button>
                  </form>
              </div>
          </div>
      </div>
  </div> `;

    document.body.insertAdjacentHTML('beforeend', modalsHtml);

    // Obtener el select de direcciones en el modal recién insertado
    const selectDireccion = document.getElementById('shippingAddress');

    // Crear opciones de dirección y agregarlas al select
    direcciones.forEach(direccion => {
        const option = document.createElement('option');
        option.value = direccion.nombre;
        option.textContent = direccion.nombre;
        selectDireccion.appendChild(option);
    });
}

function createPaymentModal() {
    let subtotal = calcularPrecio();

    const modalsHtml = `
    <!-- Payment Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-0">
                    <h2 class="modal-title text-center mb-4" id="paymentModalLabel">Forma de Pago</h2>
                    
                    <div class="d-flex justify-content-center gap-4 mb-4">
                        <div class="icon-container">
                            <i class="bi bi-check-lg"></i>
                        </div>
                        <div class="icon-container">
                            <i class="bi bi-credit-card"></i>
                        </div>
                    </div>

                    <h3 class="mb-3">Método de pago</h3>
                    
                    <div class="d-flex justify-content-between mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="paymentMethod" id="creditCard" checked>
                            <label class="form-check-label" for="creditCard">
                                Tarjeta de crédito
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="paymentMethod" id="bankTransfer">
                            <label class="form-check-label" for="bankTransfer">
                                Transferencia bancaria
                            </label>
                        </div>
                    </div>

                    <div id="creditCardContent">
                        <p class="text-sm font-medium mb-2">Tarjetas guardadas</p>

                        <div id="savedCards">
<!--.........................................TARJETAS GUARDADAS..........................................-->

                        </div>
                        
                        <button id="addNewCardBtn" class="btn btn-outline-primary w-100 py-2">
                            Agregar nueva tarjeta
                        </button>
                    </div>

                    <div id="bankTransferContent" style="display: none;">
                        <button class="btn btn-primary w-100 py-2 d-flex align-items-center justify-content-center gap-2">
                            <i class="bi bi-upload"></i>
                            Subir comprobante
                        </button>
                    </div>

                    <div class="bg-light rounded p-3 my-4">
                        <div class="d-flex justify-content-end mb-2">
                            <span class="text-primary small">Moneda: USD</span>
                        </div>
                        <h4 class="mb-3">Resumen de costos</h4>
                        <div class="summary-item">
                            <span>Subtotal:</span>
                            <span>${subtotal.toFixed(2)}</span>
                        </div>
                        <div class="summary-item">
                            <span>Costo de envío:</span>
                            <span id="costoEnvio"></span>
                        </div>
                        <div class="summary-item border-top pt-2 fw-bold">
                            <span>Total:</span>
                            <span id="costoTotal"></span>
                        </div>
                    </div>

                    <div class="d-flex gap-3">
                        <button class="btn btn-outline-secondary flex-grow-1" data-bs-dismiss="modal" id="backToShipping">Volver</button>
                        <button class="btn btn-primary flex-grow-1" id="finalizarCompra">Finalizar compra</button>
                    </div>
                </div>
            </div>
        </div>
    </div> `;

    document.body.insertAdjacentHTML('beforeend', modalsHtml);

    let cards = JSON.parse(localStorage.getItem("cards")) || [];
    // Obtener el select de direcciones en el modal recién insertado
    const savedCards = document.getElementById('savedCards');

    let append = ``;
    // Crear opciones de dirección y agregarlas al select
    cards.forEach(card => {
        append += `
        <div class="form-check w-100" style="display: flex; align-items: center;">

            <input class="form-check-input" type="radio" name="selectedCard" value="${card.id}">

            <label class="form-check-label w-100 p-3" for="${card.id}">

                <div class="border rounded p-3 mb-2 d-flex align-items-center gap-3">
                    <i class="bi bi-credit-card text-muted"></i>
                    <div>
                        <div>**** **** **** ${card.cardNumber.slice(-4)}</div>
                        <div class="text-muted small">${card.fullName}</div>
                    </div>
                </div>

            </label>
        </div>     
        `
    });
    savedCards.innerHTML = append;
}

function addNewCard() {
    const newCardForm = `
    <div class="modal fade" id="addCardModal" tabindex="-1" aria-labelledby="addCardModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title w-100 text-center" id="addCardModalLabel">Agregar nueva tarjeta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addCardForm">
                        <div class="mb-3">
                            <label for="cardNumber" class="form-label">Numero de tarjeta</label>
                            <input type="text" class="form-control" id="cardNumber" placeholder="1234 1234 1234 1234">
                        </div>

                        <div class="card-type-selection">
                            <label>
                                <input type="radio" name="cardType" class="form-check-input me-2" value="Visa">
                                <svg class="visa-logo" viewBox="0 0 1000 324" width="60">
                                    <path fill="#fff" d="M651.19 0.43H348.81C166.35 0.43 17.77 149 17.77 331.47V638.53C17.77 821 166.35 969.57 348.81 969.57H651.19C833.65 969.57 982.23 821 982.23 638.53V331.47C982.23 149 833.65 0.43 651.19 0.43Z"/>
                                    <path fill="#fff" d="M434.48 413.12L344.05 560.41H296.86L252.29 431.41C250.56 425.09 249.04 422.82 243.1 419.27C232.3 412.95 214.11 407.37 197.77 403.82L198.88 413.12H274.71L309.03 528.93L365.33 413.12H434.48Z"/>
                                    <path fill="#fff" d="M454.39 560.41H398.93L441.32 413.12H496.78L454.39 560.41Z"/>
                                    <path fill="#fff" d="M633.41 475.19C633.41 457.69 620.06 445.97 595.87 445.97C583.27 445.97 570.87 448.87 555.64 454.87L548.89 419.64C564.13 413.64 585.58 408.39 608.52 408.39C655.71 408.39 687.47 433.31 687.47 472.71C687.47 503.23 668.17 523.31 649.97 533.81C632.51 543.94 624.23 550.31 624.23 560.81C624.23 567.18 629.48 573.18 640.91 573.18C653.13 573.18 668.75 568.68 681.34 562.68L688.09 597.73C674.39 603.73 654.71 608.23 636.88 608.23C591.6 608.23 570.14 584.05 570.14 553.16C570.14 523.01 589.81 503.68 608.38 492.69C625.47 482.56 633.41 476.19 633.41 475.19Z"/>
                                    <path fill="#fff" d="M787.63 560.41L751.85 413.12H803.73L823.05 507.41L869.87 413.12H921.75L848.42 560.41H787.63Z"/>
                                </svg>
                            </label>
                            <label>
                                <input type="radio" name="cardType" class="form-check-input me-2" value="Mastercard">
                                <svg class="mastercard-logo" viewBox="0 0 131.39 86.9" width="45">
                                    <path d="M48.37 15.14h34.66v56.61H48.37z" fill="#ff5f00"/>
                                    <path d="M51.94 43.45a35.94 35.94 0 0113.75-28.3 36 36 0 100 56.61 35.94 35.94 0 01-13.75-28.31z" fill="#eb001b"/>
                                    <path d="M120.5 65.76V64.6h.5v-.24h-1.19v.24h.47v1.16zm2.31 0v-1.4h-.36l-.42 1-.42-1h-.36v1.4h.26V64.7l.39.91h.27l.39-.91v1.06zM123.94 43.45a36 36 0 01-58.25 28.3 36 36 0 000-56.61 36 36 0 0158.25 28.3z" fill="#f79e1b"/>
                                </svg>
                            </label>
                        </div>

                        <div class="mb-3">
                            <label for="fullName" class="form-label">Nombre Completo</label>
                            <input type="text" class="form-control" id="fullName" placeholder="Juan Perez">
                        </div>

                        <div class="row mb-3">
                            <div class="col-sm-6">
                                <label for="expiryDate" class="form-label">Fecha de expiración</label>
                                <input type="text" class="form-control" id="expiryDate" placeholder="MM/AA">
                            </div>
                            <div class="col-sm-6">
                                <label for="cvv" class="form-label">CVV</label>
                                <input type="text" class="form-control" id="cvv" placeholder="123">
                            </div>
                        </div>

                        <div style="text-align: center;">
                            <span id="error-newCard" style="color: red;"></span>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Guardar tarjeta</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    `;
    document.body.insertAdjacentHTML('beforeend', newCardForm);
}

//mauro
function finalizarCompra() {
    const paymentModal = bootstrap.Modal.getInstance(document.getElementById('paymentModal'));

    if (validarMetodoPagoSeleccionado()) {
        alert('¡Compra exitosa!'); 
        paymentModal.hide();
        obtenerProductos([]);
        localStorage.removeItem("carrito");
    } else {
        alert('Por favor, revisa los campos antes de finalizar la compra.');
    }
}

// Función para validar si hay un método de pago seleccionado
function validarMetodoPagoSeleccionado() {
    const metodoPagoSeleccionado = document.querySelector('input[name="selectedCard"]:checked');
    return metodoPagoSeleccionado !== null;
}