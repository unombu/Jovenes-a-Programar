const express = require('express');
const app = express();
const jwt = require("jsonwebtoken");//token
const cors = require('cors');

const port = 3000;

// Middleware para analizar JSON
app.use(express.json());

// Configuración básica para permitir todas las peticiones
app.use(cors());

// Ruta de prueba
app.get('/funcando', authenticateToken, (req, res) => {
    res.send('¡Servidor funcionando epico aguante chayanne!');
});


app.get('/categorias', authenticateToken, (req, res) => {
    const categorias = require("./data/cats/cat.json");
    res.json(categorias);
});

app.get('/categorias/:catID', authenticateToken, (req, res) => {
    const productosCategoria = require(`./data/cats_products/${req.params.catID}.json`);
    res.json(productosCategoria);
});

app.get('/productos/:productoID', authenticateToken, (req, res) => {
    const producto = require(`./data/products/${req.params.productoID}.json`);
    res.json(producto);
});

app.get('/comentarios/:productoID', authenticateToken, (req, res) => {
    const comentarios = require(`./data/products_comments/${req.params.productoID}.json`);
    res.json(comentarios);
});

const SECRET_KEY = "chayanneGod"; // Clave secreta para firmar los tokens

// Endpoint de login
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            status: "error",
            message: "Faltan credenciales",
        });
    } else {
        // usuario valido, genera token con sign(algo q identifica al usuario , clave secreta , opciones como expiracion)
        const token = jwt.sign({ email }, SECRET_KEY, { expiresIn: "24h" });

        res.json({
            status: "ok",
            message: "Autenticación exitosa",
            token: token
        });
    }
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});


//middleware
function authenticateToken(req, res, next) {
    // Obtener el token del encabezado de autorización
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Formato: "Bearer TOKEN"
  
    if (!token) {
      return res.status(401).json({ error: 'Acceso denegado. Token no proporcionado.' });
    }
  
    // Verificar y decodificar el token
    jwt.verify(token, SECRET_KEY, (err) => {
      if (err) {
        return res.status(403).json({ error: 'Token no válido o expirado.' });
      }
      next(); //aca salgo
    });
  }