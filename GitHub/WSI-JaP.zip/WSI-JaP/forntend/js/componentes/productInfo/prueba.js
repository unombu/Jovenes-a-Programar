const idInfo = localStorage.getItem("prodINFOID");
const container_info = document.getElementById("container-info");
const comment = PRODUCT_INFO_COMMENTS_URL + idInfo + EXT_TYPE;
const prodInfo = PRODUCT_INFO_URL + idInfo + EXT_TYPE;
let commentArray = [];
let prodInfoArray = [];

document.addEventListener("DOMContentLoaded", () => {
    Promise.all([getJSONData(prodInfo), getJSONData(comment)]).then(
        ([prodData, commentData]) => {
            if (prodData.status === "ok" && commentData.status === "ok") {
                prodInfoArray = prodData.data;
                commentArray = commentData.data;
                renderProductInfo(prodInfoArray, commentArray);
            }
        }
    );
});
function setRelatedProductId(id) {
    localStorage.setItem("prodINFOID", id);
    window.location = "product-info.html";
}
function addToCart(productId) {
    const currentCart = JSON.parse(localStorage.getItem("carrito")) || [];
    const productIndex = currentCart.findIndex((product) => product.id === productId);
    if (productIndex === -1) {
        currentCart.push({ id: productId, quantity: 1 });
    } else {
        currentCart[productIndex].quantity += 1;
    }
    localStorage.setItem("carrito", JSON.stringify(currentCart));
    window.location.href = "cart.html";
}

function renderProductInfo(product, comments) {
    const images = product.images.slice(1, 4).map((image, index) => `
        <img src="${image}" alt="Miniatura" class="img-event" data-index="${index + 1}">
    `).join('');

    const commentsList = comments.map((comment, index) => {
        const stars = Array(5).fill('&#9733;').map((star, i) => i < comment.score ? `<span class="star-filled">&#9733;</span>` : `<span class="star-empty">&#9734;</span>`).join('');
        const formattedDate = formatDateTime(comment.dateTime);
        return `
            <div class="${index % 2 === 0 ? 'even-comment' : 'odd-comment'}">
                <div class="commentsData">
                    <div class="commentsNS">
                        <strong id="userC"><p>${comment.user}</p></strong>
                        <p>${stars}</p>
                    </div>
                    <p class="commentsDT">${formattedDate}</p>
                </div>
                <p id="descproduinfo">${comment.description}</p>
            </div>
        `;
    }).join('');

    const container = document.getElementById('container-info');
    container.innerHTML = `
        <h1>${product.category}</h1>
        <h2 class="car-div-main">${product.name}</h2>
        <div class="car-main">
            <div class="car-details">
                <div class="main-image">
                    <img class="car-image" id="main-image" src="${product.images[0]}" alt="${product.name}">
                </div>
                <p class="description">${product.description}</p>
                <p class="price">${product.currency} ${product.cost}</p>
            </div>
            <div class="car-images">
                ${images}
                <p class="sold-count">${product.soldCount} vendidos</p>
                <button class="btn btn-primary w-auto" onclick="addToCart(${product.id})">Comprar</button>
            </div>
        </div>
        <div class="mainReseña">
            <div class="styleReseña">
                <h3>Deja tu Reseña</h3>
                <div class="star-rating">
                    <input type="radio" id="star5" name="rating" value="5">
                    <label for="star5">&#9733;</label>
                    <input type="radio" id="star4" name="rating" value="4">
                    <label for="star4">&#9733;</label>
                    <input type="radio" id="star3" name="rating" value="3">
                    <label for="star3">&#9733;</label>
                    <input type="radio" id="star2" name="rating" value="2">
                    <label for="star2">&#9733;</label>
                    <input type="radio" id="star1" name="rating" value="1">
                    <label for="star1">&#9733;</label>
                </div>
            </div>
            <div class="styleTB">
                <textarea class="form-control mt-3" placeholder="Escribe tu opinión aquí..." rows="3" id="comentario"></textarea>
                <button class="btn btn-primary" id="enviar-opinion">Enviar</button>
            </div>
        </div>
        <h3>Opiniones Destacadas </h3>
        <div class="comment ">${commentsList}</div>
        <h3 class="relatedTitle">Quienes compraron este producto también vieron</h3>
        <div class="car-secondary">
            ${product.relatedProducts.map(product => `
                <div class="car" id="${product.id}">
                    <h3>${product.name}</h3>
                    <img src="${product.image}" alt="${product.name}">
                    <div onclick="setrelatedproductID(${product.id})">
                        <a class="btn" >VER</a>
                    </div>
                </div>
            `).join('')}
        </div>
    `;

    const mainImage = document.getElementById('main-image');
    const mainImageSrc = mainImage.src;

    document.querySelectorAll('.car-images img').forEach(element => {
        element.addEventListener('click', function() {
            let clickedImageSrc = element.src;
            mainImage.src = clickedImageSrc;
            element.src = mainImageSrc;
            mainImageSrc = clickedImageSrc;
        });
    });
}


document.addEventListener("change", function (event) {
    if (
        event.target.closest(".star-rating") &&
        event.target.matches('input[type="radio"]')
    ) {
        score = event.target.value;
    }
});

document.addEventListener("click", function (event) {
    if (event.target && event.target.id === "enviar-opinion") {
        let fecha = formatDateTime(new Date());
        let desc = document.getElementById("comentario").value.trim();
        if (!score) {
            Swal.fire({
                icon: "error",
                title: "Debe calificar el producto para enviar su opinion",
                confirmButtonText: "Aceptar",
            });
            return;
        }
        if (desc === '') {
            Swal.fire({
                icon: "error",
                title: "Porfavor deje un comentario antes de enviar su opinion",
                confirmButtonText: "Aceptar",
            });
            return;
        }
        let usuario = JSON.parse(localStorage.getItem("user"));
        let nuevaOpinion = {
            dateTime: fecha,
            description: desc,
            score: score,
            user: usuario.firstName + "_" + usuario.lastName,
        };

        commentArray.push(nuevaOpinion);
        renderProductInfo(prodInfoArray, commentArray);
        score = undefined;
    }
});
function formatDateTime(dateString) {
    const date = new Date(dateString);
    const day = `0${date.getDate()}`.slice(-2);
    const month = `0${date.getMonth() + 1}`.slice(-2);
    const year = date.getFullYear().toString().slice(-2);
    const hour = `0${date.getHours()}`.slice(-2);
    const minute = `0${date.getMinutes()}`.slice(-2);

    return `${day}-${month}-${year} | ${hour}:${minute}`;
}
