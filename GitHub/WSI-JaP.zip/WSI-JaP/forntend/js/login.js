import hashedPasswords from "./utils/hashpwd.js"
document.getElementById("registrar").addEventListener("click",()=>{
    window.location="register.html"
})

document.getElementById("ingresar").addEventListener("click", async function(e) {
    e.preventDefault();

    const email = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const usernameError = document.getElementById("usernameError");
    const passwordError = document.getElementById("passwordError");

    usernameError.textContent = "";
    passwordError.textContent = "";

    let valid = true;

    if (!email) {
        usernameError.textContent = "El correo electrónico es obligatorio.";
        valid = false;
    } else if (!password) {
        passwordError.textContent = "La contraseña es obligatoria.";
        valid = false;
    } else if (password.length < 6) {
        passwordError.textContent = "La contraseña debe tener al menos 6 caracteres.";
        valid = false;
    }

    if (valid) {
        const hashedPassword = await hashedPasswords(password);

        const users = JSON.parse(localStorage.getItem("users")) || [];
        const user = users.find(user => user.email === email && user.password === hashedPassword);

        if (user) {
            const response = await fetch("http://localhost:3000/login", {
                method: "POST", //llamar al post en el endpoint /login
                headers: {
                    "Content-Type": "application/json", //esto es coso default (?)
                },
                body: JSON.stringify({ email, password }),
            });
        
            if (response.ok) {
                const data = await response.json();
                localStorage.setItem("token", data.token);
                console.log(localStorage.getItem("token"));
            } else {
                const error = await response.json();
                console.error("Error en el login:", error.message);
            }
        
            localStorage.setItem("logeado", true);
            localStorage.setItem("user", JSON.stringify(user));
            window.location.href = "index.html";
        } else {
            usernameError.textContent = "";
            passwordError.textContent = "";
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Correo electrónico o contraseña incorrectos.',
                confirmButtonText: 'Aceptar'
            });
        }
    }
});
