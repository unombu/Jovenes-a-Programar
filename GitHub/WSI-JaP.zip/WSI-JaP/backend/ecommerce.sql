CREATE TABLE cart ( 
    user_id INTEGER, 
    id SERIAL PRIMARY KEY, 
    products INTEGER[] 
);

SELECT * FROM cart;

INSERT INTO cart (user_id, products) VALUES (1, ARRAY[40281, 50741, 60804]);

SELECT * FROM cart;